package com.myproject.payroll;

enum Status {

    IN_PROGRESS, //
    COMPLETED, //
    CANCELLED
}
